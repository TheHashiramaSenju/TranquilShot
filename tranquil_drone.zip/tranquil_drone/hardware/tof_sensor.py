import smbus2
import VL53L1X
from config import CFG


class DistanceSensor:
    def __init__(self):
        self._tof = VL53L1X.VL53L1X(
            i2c_bus=CFG.hardware.TOF_I2C_BUS,
            i2c_address=CFG.hardware.TOF_I2C_ADDRESS
        )
        self._tof.open()
        self._tof.set_timing(
            CFG.hardware.TOF_TIMING_BUDGET_MS * 1000,
            CFG.hardware.TOF_TIMING_BUDGET_MS + 5
        )
        self._tof.start_ranging(2)
        self._last_valid_mm: int = 0

    def get_distance_mm(self) -> int:
        try:
            raw = self._tof.get_distance()
            if raw > 0:
                self._last_valid_mm = raw
            return self._last_valid_mm
        except OSError:
            return self._last_valid_mm

    def close(self) -> None:
        try:
            self._tof.stop_ranging()
            self._tof.close()
        except Exception:
            pass
