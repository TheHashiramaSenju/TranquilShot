# TranquilShot — Autonomous Tranquilizer Drone

## Hardware Configuration

| Component         | Part                    | Interface | Address / Port       |
|-------------------|-------------------------|-----------|----------------------|
| Flight Controller | Pixhawk 6C / Cube Orange | UART      | `/dev/ttyAMA0` 921600 baud |
| Companion Computer| Raspberry Pi 4B / 5     | —         | Runs `main.py`       |
| Vision AI         | Google Coral USB Accel  | USB 3.0   | Auto-detected by PyCoral |
| Camera            | Pi Camera Module 3       | CSI       | Index `0`            |
| Depth Sensor      | ST VL53L1X              | I2C Bus 1 | `0x29` (default)    |
| Payload           | Servo-actuated dart gun | AUX PWM 9 | 1000–2000 µs pulse  |
| Battery           | 4S LiPo                 | XT60      | RTL below 14.2V      |

---

## File Build Order (Read This Before Touching Anything)

Files were written and must be understood in this exact dependency order.
Every file only imports from files above it in this list.

### Step 1 — `config.py`
**No imports from this project.**
This is the single source of truth for every number in the system.
Frozen dataclasses prevent accidental mutation at runtime.
All other files import `CFG` from here.
Never put logic, conditions, or functions here — only uppercase constants.

### Step 2 — `utils/math_helpers.py`
**Imports:** `config.CFG`, standard library `time` only.
Contains `PIDController` and two pure utility functions.
The PID implements anti-windup clamping on the integral term.
Zero hardware knowledge here — takes a number, returns a number.

### Step 3 — `utils/logger.py`
**Imports:** `config.CFG`, standard library `csv`, `time`, `pathlib`.
Writes one `FlightRecord` dataclass row per heartbeat to a timestamped CSV.
If `ENABLE_LOGGING = False`, every call is a no-op, zero overhead.

### Step 4 — `hardware/tof_sensor.py`
**Imports:** `smbus2`, `VL53L1X`, `config.CFG`.
Opens I2C bus 1, address `0x29`.
Ranging mode 2 = long range (up to 4m reliable, 8m max).
`get_distance_mm()` caches last valid reading — never returns zero.

### Step 5 — `hardware/camera_tpu.py`
**Imports:** `cv2`, `pycoral`, `config.CFG`.
Loads the `.tflite` model onto the Edge TPU, opens the camera.
`detect_target()` returns the highest-confidence `Detection` matching `TARGET_LABEL`, or `None`.
Bounding box coordinates are rescaled from TPU input resolution back to full frame resolution.

### Step 6 — `hardware/pixhawk_link.py`
**Imports:** `pymavlink`, `config.CFG`, `utils.math_helpers.clamp`.
Establishes MAVLink heartbeat on startup — constructor will raise if Pixhawk is not connected.
`send_velocity()` uses `MAV_FRAME_BODY_OFFSET_NED` so velocities are always relative to the drone's nose direction.
type_mask `0b0000_0111_0110_0111` enables only velocity + yaw rate.
Velocity commands must be re-sent every <1 second or the Pixhawk stops — `needs_velocity_refresh()` handles this.
`fire_payload()` sends a 2000µs servo pulse, waits `FIRING_PULSE_DURATION_S`, resets to 1000µs.

### Step 7 — `main.py`
**Imports:** Everything above.
The only file that orchestrates the full system.
Implements a 9-state finite state machine:

```
PREFLIGHT → TAKEOFF → SCANNING ⟷ APPROACHING ⟷ TRACKING → LOITERING → FIRE → COOLDOWN → SCANNING
                                                                                        ↓ (battery low anywhere)
                                                                                        RTL
```

State transitions:
- `PREFLIGHT` — checks battery voltage, sets GUIDED mode
- `TAKEOFF` — arms and climbs to `TAKEOFF_ALTITUDE_M`
- `SCANNING` — yaws at `SCAN_YAW_RATE_RDS` until a target appears
- `APPROACHING` — PID tracks target but distance outside firing envelope
- `TRACKING` — PID tracks target within firing envelope
- `LOITERING` — hovering, fine-aligning before commit to fire
- `FIRE` — fires servo payload once
- `COOLDOWN` — mandatory `FIRING_COOLDOWN_S` hold before re-entering scan
- `RTL` — battery failsafe, calls `return_to_launch()`

The heartbeat loop runs at `1 / HEARTBEAT_INTERVAL_S` Hz (default 20 Hz).
Occlusion tolerance: if target disappears, drone holds position for `OCCLUSION_TIMEOUT_S` seconds before giving up and re-scanning.

---

## Installation on Raspberry Pi

```bash
sudo apt-get update
sudo apt-get install python3-pip python3-dev i2c-tools libatlas-base-dev

# Coral Edge TPU runtime
echo "deb https://packages.cloud.google.com/apt coral-edgetpu-stable main" | \
  sudo tee /etc/apt/sources.list.d/coral-edgetpu.list
curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
sudo apt-get update && sudo apt-get install libedgetpu1-std python3-pycoral

# Enable I2C
sudo raspi-config  # Interface Options → I2C → Enable

pip install -r requirements.txt
```

## Run

```bash
python main.py
```

Use `Ctrl+C` to trigger RTL safely.
